import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';

const App = () => {
  const canvasRef = useRef(null);
  const modelRef = useRef(null);
  const homePositionRef = useRef(new THREE.Vector3());
  const homeRotationRef = useRef(new THREE.Euler());
  const [shadowsEnabled, setShadowsEnabled] = useState(false);
  const [modelColor, setModelColor] = useState("#ffffff");
  const [isGlossy, setIsGlossy] = useState(true);
  const [backgroundColor, setBackgroundColor] = useState("#000000");

  const resetModelPosition = () => {
    if (modelRef.current) {
      modelRef.current.position.copy(homePositionRef.current);
      modelRef.current.rotation.copy(homeRotationRef.current);
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;

    // Scene, Camera, Renderer
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 2, 5);

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true; // Enable shadow map for the renderer
    renderer.shadowMap.type = THREE.PCFSoftShadowMap; // Use soft shadows

    // Update Background Color
    scene.background = new THREE.Color(backgroundColor);

    // Lighting (Directional Light)
    const light = new THREE.DirectionalLight(0xffffff, 2);
    light.position.set(5, 10, 7.5);
    light.castShadow = shadowsEnabled; // Enable shadow casting for the light
    scene.add(light);

    // Set up shadow for the light
    light.shadow.mapSize.width = 1024;  // Shadow quality (width)
    light.shadow.mapSize.height = 1024; // Shadow quality (height)
    light.shadow.camera.near = 0.1; // Shadow camera near clipping
    light.shadow.camera.far = 20;   // Shadow camera far clipping
    light.shadow.camera.left = -5;
    light.shadow.camera.right = 5;
    light.shadow.camera.top = 5;
    light.shadow.camera.bottom = -5;

    // Ground Plane (for Shadows)
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(10, 10),
      new THREE.MeshBasicMaterial({ color: 0x808080 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = shadowsEnabled; // Enable receiving shadows
    scene.add(ground);

    // GLTF Loader for Model
    const loader = new GLTFLoader();
    loader.load('/Chair.glb', (gltf) => {
      const model = gltf.scene;

      // Set initial position and rotation
      model.position.set(0, 0, 0);
      model.rotation.set(0, 0, 0);
      homePositionRef.current.copy(model.position); // Store initial position
      homeRotationRef.current.copy(model.rotation); // Store initial rotation
      modelRef.current = model; // Store the model reference

      model.traverse((child) => {
        if (child.isMesh) {
          child.castShadow = shadowsEnabled;
          child.receiveShadow = true;
          child.material = new THREE.MeshStandardMaterial({
            color: modelColor,
            metalness: isGlossy ? 1 : 0,
            roughness: isGlossy ? 0.1 : 1,
          });
        }
      });
      scene.add(model);
    });

    // Orbit Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 1;
    controls.maxDistance = 10;
    controls.target.set(0, 1, 0); // Focus point

    // Animation Loop
    const animate = () => {
      requestAnimationFrame(animate);
      if (modelRef.current) {
        modelRef.current.rotation.y += 0.001;  // Rotate model continuously for animation
      }
      controls.update(); // Update controls
      renderer.render(scene, camera);
    };
    animate();

    // Cleanup
    return () => {
      renderer.dispose();
      controls.dispose();
    };
  }, [shadowsEnabled, modelColor, isGlossy, backgroundColor]);

  return (
    <div>
      <canvas ref={canvasRef} />
      <div style={{ position: 'absolute', top: 10, left: 10 }}>
        {/* Toggle Shadows */}
        <button onClick={() => setShadowsEnabled((prev) => !prev)}>
          Toggle Shadows: {shadowsEnabled ? "On" : "Off"}
        </button>

        {/* Change Model Color */}
        <input
          type="color"
          value={modelColor}
          onChange={(e) => setModelColor(e.target.value)}
        />
        <span>Change Model Color</span>

        {/* Toggle Glossy Effect */}
        <button onClick={() => setIsGlossy((prev) => !prev)}>
          Toggle Glossy: {isGlossy ? "Glossy" : "Non-Glossy"}
        </button>

        {/* Change Background Color */}
        <input
          type="color"
          value={backgroundColor}
          onChange={(e) => setBackgroundColor(e.target.value)}
        />
        <span>Change Background Color</span>

        {/* Reset to Home Position */}
        <button onClick={resetModelPosition}>Reset to Home Position</button>
      </div>
    </div>
  );
};

export default App;
