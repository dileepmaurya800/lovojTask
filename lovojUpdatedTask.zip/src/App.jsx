import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import { TransformControls } from 'three/examples/jsm/controls/TransformControls';

const App = () => {
  const canvasRef = useRef(null);
  const modelRef = useRef(null);
  const homePositionRef = useRef(new THREE.Vector3());
  const homeRotationRef = useRef(new THREE.Euler());
  const [shadowsEnabled, setShadowsEnabled] = useState(false);
  const [modelColor, setModelColor] = useState("#ffffff");
  const [isGlossy, setIsGlossy] = useState(true);
  const [backgroundColor, setBackgroundColor] = useState("#000000");

  // const resetModelPosition = () => {
  //   if (modelRef.current) {
  //     modelRef.current.position.copy(homePositionRef.current); // Reset position
  //     modelRef.current.rotation.copy(homeRotationRef.current); // Reset rotation
  //     modelRef.current.updateMatrixWorld(); // Ensure the changes are applied
  //   }
  // };
  

  useEffect(() => {
    const canvas = canvasRef.current; 
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    const scene = new THREE.Scene();
    let modelObj =[];
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 2, 5);

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    scene.background = new THREE.Color(backgroundColor);

    const light = new THREE.DirectionalLight(0xffffff, 1);
    light.position.set(5, 10, 7.5);
    light.castShadow = shadowsEnabled;
    scene.add(light);

    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(10, 10),
      new THREE.MeshBasicMaterial({ color: 0x808080 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = shadowsEnabled;
    scene.add(ground);

    const textureLoader = new THREE.TextureLoader();
    const newTexture = textureLoader.load('/texture1.jpg'); 
    let transformControls = new TransformControls(camera, renderer.domElement);

    const loader = new GLTFLoader();
    loader.load('/Chair.glb', (gltf) => {
      const model = gltf.scene;
      model.position.set(0, 0, 0);
      model.rotation.set(0, 0, 0);
      homePositionRef.current.copy(model.position);
      homeRotationRef.current.copy(model.rotation);
      modelRef.current = model;

      model.traverse((child) => {
        
        if (child.isMesh) {
          modelObj.push(child);
          child.castShadow = shadowsEnabled;
          child.receiveShadow = true;
          child.material = new THREE.MeshBasicMaterial({
            color: modelColor,
            metalness: isGlossy ? 1 : 0,
            roughness: isGlossy ? 0.1 : 1,
          });
        }
      });
      scene.add(model);
      // ----------------------------------------------------------------------------------------------
     
      // Add TransformControls and attach to the model
      // transformControls.attach(model);
      // scene.add(transformControls);

      // Disable OrbitControls when using TransformControls
      const gizmo = transformControls.getHelper();
			scene.add( gizmo );
      transformControls.addEventListener('dragging-changed', (event) => {
        orbitControls.enabled = !event.value;
      });

      transformControls.addEventListener('change', () => {
        renderer.render(scene, camera);
      });
    });
    // ----------------------------------------------------------------------------------------------------

    function onPointerClick(event) {
      event.preventDefault();
     
      // Update pointer position for raycaster
      pointer.x = (event.clientX / window.innerWidth) * 2 - 1;
      pointer.y = -(event.clientY / window.innerHeight) * 2 + 1;

      raycaster.setFromCamera(pointer, camera);

      const intersects = raycaster.intersectObjects(modelObj);
      if (intersects.length > 0) {
        const clickedObject = intersects[0].object;
        if (clickedObject.isMesh) {
          transformControls.attach(clickedObject);
          clickedObject.material.map = newTexture; 
          clickedObject.material.needsUpdate = true; 
        }
        else{
          transformControls.detach();
        }
      }
    }

    window.addEventListener('click', onPointerClick);

    // Add OrbitControls
    const orbitControls = new OrbitControls(camera, renderer.domElement);
    orbitControls.enableDamping = true;
    orbitControls.dampingFactor = 0.05;
    orbitControls.minDistance = 1;
    orbitControls.maxDistance = 10;
    orbitControls.target.set(0, 1, 0);

    const animate = () => {
      requestAnimationFrame(animate);
      orbitControls.update();
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      renderer.dispose();
      orbitControls.dispose();
      window.removeEventListener('click', onPointerClick);
    };
  }, [shadowsEnabled, modelColor, isGlossy, backgroundColor]);

  return (
    <div>
      <canvas ref={canvasRef} />
      <div style={{ position: 'absolute', top: 10, left: 10 }}>
        {/* Toggle Shadows */}
        <button onClick={() => setShadowsEnabled((prev) => !prev)}>
          Toggle Shadows: {shadowsEnabled ? "On" : "Off"}
        </button>

        {/* Change Model Color */}
        <input
          type="color"
          value={modelColor}
          onChange={(e) => setModelColor(e.target.value)}
        />
        <span>Change Model Color</span>

        {/* Toggle Glossy Effect */}
        <button onClick={() => setIsGlossy((prev) => !prev)}>
          Toggle Glossy: {isGlossy ? "Glossy" : "Non-Glossy"}
        </button>

        {/* Change Background Color */}
        <input
          type="color"
          value={backgroundColor}
          onChange={(e) => setBackgroundColor(e.target.value)}
        />
        <span>Change Background Color</span>

        {/* Reset to Home Position */}
        {/* <button onClick={resetModelPosition}>Reset to Home Position</button> */}
      </div>
    </div>
  );
};

export default App;
